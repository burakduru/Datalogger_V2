﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.Globalization;

namespace DataLoggerNMEA
{
    public partial class Form1 : Form
    {
        public bool port_is_open = false;
        string strRecieved;
        public const int Index_max_Tab = 10;
        string[] CurrentLineTab = new string[Index_max_Tab];
        int index_tab_currentLine = 0;
        public int nbre_ports_serie_trouves = 0;

        string[] strPortsList = new string[100];
        List<double> liste_temperature_double = new List<double>();
        List<double> liste_vbat_double = new List<double>();
        List<double> liste_5Vteensy = new List<double>();
        List<double> liste_choixtension = new List<double>();
        List<double> liste_date_OA = new List<double>();
        List<List<double>> liste_all_temperature_double = new List<List<double>>();
        List<double> liste_choixtemperature = new List<double>();

        List<double[]> liste_all_temperatures_d = new List<double[]>();
        List<double[]> liste_all_dates_OA = new List<double[]>();

        public char crc_xor(string chaine_string)
        {
            char xor = (char)0;

            char[] charArr = chaine_string.ToCharArray();
            int longueur = chaine_string.Length;
            if (longueur > 4)
            {
                for (int indice = 0; indice < longueur; indice++)
                    xor ^= charArr[indice];


            }
            return xor;
        }
        public int[] shiftLeft(int[] arr)
        {
            int[] demo = new int[arr.Length];


            for (int i = 0; i < arr.Length; i++)
            {
                demo[(i + 1) % demo.Length] = arr[i];

            }

            return demo;
        }

        public double[] shiftRight(double[] arr)
        {
            double[] demo = new double[arr.Length];


            for (int i = 0; i < arr.Length; i++)
            {
                demo[i] = arr[(i + 1) % demo.Length];

            }

            return demo;
        }

        public void UpdateCOMPort()
        {
            nbre_ports_serie_trouves = 0;

            if (SerialPort.GetPortNames().Length == 0)
            {
                textBox2.Text = "!!!!!!!!!Ce PC ne contient aucun port COM";

                OpenCloseSerialPort.Enabled = false;
            }
            else
            {
                OpenCloseSerialPort.Enabled = false;
                strPortsList = SerialPort.GetPortNames();
                listBox1.Items.Clear();
                foreach (string s in strPortsList)
                {
                    listBox1.Items.Add(s);
                    nbre_ports_serie_trouves++;
                }
                textBox2.Text = "Ce PC contient " + nbre_ports_serie_trouves.ToString() + " ports COM";
            }
        }
        public Form1()
        {
            InitializeComponent();
            OpenCloseSerialPort.Text = "Open COM";
            UpdateCOMPort();
        }

        private void OpenCloseSerialPort_Click(object sender, EventArgs e)
        {
            if (port_is_open == false)
            {
                try
                {
                    if ((listBox1.SelectedIndex > -1) && (listBox1.SelectedIndex < nbre_ports_serie_trouves))
                    {
                        serialPort1.PortName = (strPortsList[listBox1.SelectedIndex]);
                        serialPort1.Open();

                        port_is_open = true;
                        OpenCloseSerialPort.Text = "Close COM";
                        button_refresh_com_port.Enabled = false;
                        listBox1.Enabled = false;
                        textBox2.Text = "OPEN PORT OK " + serialPort1.PortName + " " + DateTime.Now.ToString("HH:mm:ss.fff");
                    }
                }
                catch
                {
                    textBox2.Text = "OPEN PORT NOK " + serialPort1.PortName + " " + DateTime.Now.ToString("HH:mm:ss.fff");
                }
            }
            else
            {
                try
                {
                    serialPort1.Close();

                }
                catch
                {

                }
                port_is_open = false;
                OpenCloseSerialPort.Text = "Open COM";
                button_refresh_com_port.Enabled = true;
                listBox1.Enabled = true;
            }
        }
        StringBuilder sb = new StringBuilder();
        char LF = (char)10;
        char CR = (char)10;
        bool start_car_detecte = false;
        char START = '$';
        bool SerialPortDataReceivedAlreadyEntered = false;

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            if (SerialPortDataReceivedAlreadyEntered == true)
                return;
            SerialPortDataReceivedAlreadyEntered = true;

            string Data = serialPort1.ReadExisting();

            foreach (char c in Data)
            {
                if (c == START)
                    start_car_detecte = true;

                if (start_car_detecte == true)
                {
                    if (c == CR)
                    {
                        sb.Append(c);

                        CurrentLineTab[index_tab_currentLine] = sb.ToString();
                        sb.Clear();
                        start_car_detecte = false;
                        //do something with your response 'CurrentLine'
                        //strRecieved = CurrentLine;
                        Eval_String(CurrentLineTab[index_tab_currentLine], index_tab_currentLine);
                        index_tab_currentLine++;
                        if (index_tab_currentLine > (CurrentLineTab.Length - 1))
                        {
                            index_tab_currentLine = 0;
                        }
                    }
                    else
                    {

                        sb.Append(c);
                    }
                }
            }
            SerialPortDataReceivedAlreadyEntered = false;



        }
        public bool fonction_deja_entree = false;
        public int indice_point = 0;
        public bool reset_graph_1_demande = false;
        public bool update_tension = false;
        public bool update_temperature = false;
        double temperature_ysi = 9997;
        double YSI_1, YSI_2, YSI_3, YSI_4, YSI_5, YSI_6, YSI_7 = 9997;
        double YSI_8, YSI_9, YSI_10, YSI_11 = 9997;
        double vbat_data_logger = 9997;
        double V_teensy = 9997;
        double V1, V2, V3, V4, V5, V6 = 9997;
        double V_choix = 0;
        double temperature_choix = 0;
        double Vchoix = 0;
        double[] all_temperatures_ysi = new double[16];

        private void Eval_String(string s, int index)
        {
            if (fonction_deja_entree == true)
                return;
            fonction_deja_entree = true;
            textBox1.Text = (s + Environment.NewLine);

            string[] ArgumentList = s.Split(',');

            if (ArgumentList[0].Contains("DTUDIAL") == true)
            {
                textBox_Argument.Text = DateTime.Now.ToString("HH:mm:ss.fff") + " : Arguments decodes " + Environment.NewLine; ;
                int numero_argument = 0;
                foreach (string argument in ArgumentList)
                {
                    textBox_Argument.Text += argument + Environment.NewLine;

                    numero_argument++;



                }     /*  textBox2.Text = DateTime.Now.ToString("HH:mm:ss.fff")+" : Detection DATAUDIAL ";
                    textBox2.Text += Environment.NewLine;
                   */


                //arg 1 = date

                //la temperature est a partir de l'argument numero 2

                bool isNumeric = double.TryParse(ArgumentList[2], NumberStyles.Number, //YSI_0
                    CultureInfo.CreateSpecificCulture("en-US"), out temperature_ysi);

                bool une_valeur_est_bonne_bool = false;
                if (temperature_ysi < 9997 && isNumeric == true)
                {
                    all_temperatures_ysi[0] = temperature_ysi;
                    une_valeur_est_bonne_bool = true;

                }

                isNumeric = double.TryParse(ArgumentList[3], NumberStyles.Number, //YSI_1
                CultureInfo.CreateSpecificCulture("en-US"), out YSI_1);

                une_valeur_est_bonne_bool = false;
                if (YSI_1 < 997 && isNumeric == true )
                {
                    all_temperatures_ysi[0] = YSI_1;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[4], NumberStyles.Number, //YSI_2
                CultureInfo.CreateSpecificCulture("en-US"), out YSI_2);

                une_valeur_est_bonne_bool = false;
                if (YSI_2 < 997 && isNumeric == true)
                {
                    all_temperatures_ysi[0] = YSI_2;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[5], NumberStyles.Number, //YSI_3
                CultureInfo.CreateSpecificCulture("en-US"), out YSI_3);

                une_valeur_est_bonne_bool = false;
                if (YSI_3 < 997 && isNumeric == true)
                {
                    all_temperatures_ysi[0] = YSI_3;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[6], NumberStyles.Number, //YSI_4
                CultureInfo.CreateSpecificCulture("en-US"), out YSI_4);

                une_valeur_est_bonne_bool = false;
                if (YSI_4 < 997 && isNumeric == true)
                {
                    all_temperatures_ysi[0] = YSI_4;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[7], NumberStyles.Number, //YSI_5
                CultureInfo.CreateSpecificCulture("en-US"), out YSI_5);

                une_valeur_est_bonne_bool = false;
                if (YSI_5 < 997 && isNumeric == true)
                {
                    all_temperatures_ysi[0] = YSI_5;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[8], NumberStyles.Number, //YSI_6
                CultureInfo.CreateSpecificCulture("en-US"), out YSI_6);

                une_valeur_est_bonne_bool = false;
                if (YSI_6 < 997 && isNumeric == true)
                {
                    all_temperatures_ysi[0] = YSI_6;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[9], NumberStyles.Number, //YSI_7
                CultureInfo.CreateSpecificCulture("en-US"), out YSI_7);

                une_valeur_est_bonne_bool = false;
                if (YSI_7 < 997 && isNumeric == true)
                {
                    all_temperatures_ysi[0] = YSI_7;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[10], NumberStyles.Number, //YSI_8
                CultureInfo.CreateSpecificCulture("en-US"), out YSI_8);

                une_valeur_est_bonne_bool = false;
                if (YSI_8 < 997 && isNumeric == true)
                {
                    all_temperatures_ysi[0] = YSI_8;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[11], NumberStyles.Number, //YSI_9
                CultureInfo.CreateSpecificCulture("en-US"), out YSI_9);

                une_valeur_est_bonne_bool = false;
                if (YSI_9 < 997 && isNumeric == true)
                {
                    all_temperatures_ysi[0] = YSI_9;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[12], NumberStyles.Number, //YSI_10
                CultureInfo.CreateSpecificCulture("en-US"), out YSI_10);

                une_valeur_est_bonne_bool = false;
                if (YSI_10 < 997 && isNumeric == true)
                {
                    all_temperatures_ysi[0] = YSI_10;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[13], NumberStyles.Number, //YSI_11
                CultureInfo.CreateSpecificCulture("en-US"), out YSI_11);

                une_valeur_est_bonne_bool = false;
                if (YSI_11 < 997 && isNumeric == true)
                {
                    all_temperatures_ysi[0] = YSI_11;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[14], NumberStyles.Number, //V1
                CultureInfo.CreateSpecificCulture("en-US"), out V1);

                une_valeur_est_bonne_bool = false;
                if (V1 < 9997 && isNumeric == true)
                {
                    all_temperatures_ysi[1] = V1;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[15], NumberStyles.Number, //V2
                CultureInfo.CreateSpecificCulture("en-US"), out V2);

                une_valeur_est_bonne_bool = false;
                if (V2 < 9997 && isNumeric == true)
                {
                    all_temperatures_ysi[1] = V2;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[16], NumberStyles.Number, //V3
                CultureInfo.CreateSpecificCulture("en-US"), out V3);

                une_valeur_est_bonne_bool = false;
                if (V3 < 9997 && isNumeric == true)
                {
                    all_temperatures_ysi[1] = V3;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[17], NumberStyles.Number, //V4
                CultureInfo.CreateSpecificCulture("en-US"), out V4);

                une_valeur_est_bonne_bool = false;
                if (V4 < 9997 && isNumeric == true)
                {
                    all_temperatures_ysi[1] = V4;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[18], NumberStyles.Number, //V5
                CultureInfo.CreateSpecificCulture("en-US"), out V5);

                une_valeur_est_bonne_bool = false;
                if (V5 < 9997 && isNumeric == true)
                {
                    all_temperatures_ysi[1] = V5;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[19], NumberStyles.Number, //V6
                CultureInfo.CreateSpecificCulture("en-US"), out V6);

                une_valeur_est_bonne_bool = false;
                if (V6 < 9997 && isNumeric == true)
                {
                    all_temperatures_ysi[1] = V6;

                    une_valeur_est_bonne_bool = true;
                }

                isNumeric = double.TryParse(ArgumentList[20], NumberStyles.Number, //Vbat
                CultureInfo.CreateSpecificCulture("en-US"), out vbat_data_logger);

                une_valeur_est_bonne_bool = false;
                if (vbat_data_logger < 9997 && isNumeric == true)
                {
                    all_temperatures_ysi[1] = vbat_data_logger;

                    une_valeur_est_bonne_bool = true;
                }
                isNumeric = double.TryParse(ArgumentList[21], NumberStyles.Number, //5V
                CultureInfo.CreateSpecificCulture("en-US"), out V_teensy);

                une_valeur_est_bonne_bool = false;
                if (V_teensy < 997 && isNumeric == true)
                {
                    all_temperatures_ysi[1] = V_teensy;

                    une_valeur_est_bonne_bool = true;

                }

                if (une_valeur_est_bonne_bool == true)
                    data_graph_temperature_prete = true;

                textBox2.Text = isNumeric.ToString() + " - YSI Temperature " + temperature_ysi.ToString("#.##") + " indice : " + indice_point.ToString() + Environment.NewLine;


            }
            fonction_deja_entree = false; }

        private void button_refresh_com_port_Click(object sender, EventArgs e)
        {
            if (port_is_open == false)
                UpdateCOMPort();
            else
            {
                textBox1.Text = "Veuillez fermer le port serie avant de rafraichir les ports COM";
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            OpenCloseSerialPort.Enabled = true;
            if (nbre_ports_serie_trouves > 0)
            {
                textBox2.Text = "Vous voulez travailler avec Port " + strPortsList[listBox1.SelectedIndex];
                textBox2.Text += " Reste à l'ouvrir...";
            }
        }

        private void button_reset_graph_1_Click(object sender, EventArgs e)
        {
            reset_graph_1_demande = true;
        }
        public bool data_graph_temperature_prete = false;
        private void timer_refresh_graph_Tick(object sender, EventArgs e)
        {
            //rafraichissement des graphes !!
            if (data_graph_temperature_prete == true)
            {
                data_graph_temperature_prete = false;


                if (reset_graph_1_demande == true)
                {
                    indice_point = 0;
                    reset_graph_1_demande = false;
                    liste_temperature_double.Clear();
                    liste_date_OA.Clear();

                    liste_all_temperatures_d.Clear();
                    liste_all_dates_OA.Clear();
                    liste_choixtemperature.Clear();
                    liste_choixtension.Clear();
                    liste_all_temperature_double.Clear();
                }
                double date_point = DateTime.Now.ToOADate();

                if (update_temperature == true)
                {
                    int temperature_value = (int)nud_temperature_ysi.Value;

                    //Thermistance groupe n°1
                    if (temperature_value == 0) temperature_choix = temperature_ysi;
                    if (temperature_value == 1) temperature_choix = YSI_1;
                    if (temperature_value == 2) temperature_choix = YSI_2;
                    if (temperature_value == 3) temperature_choix = YSI_3;
                    if (temperature_value == 4) temperature_choix = YSI_4;
                    if (temperature_value == 5) temperature_choix = YSI_5;
                    if (temperature_value == 6) temperature_choix = YSI_6;
                    if (temperature_value == 7) temperature_choix = YSI_7;
                    //Thermistance groupe n°2
                    if (temperature_value == 8) temperature_choix = YSI_8;
                    if (temperature_value == 9) temperature_choix = YSI_9;
                    if (temperature_value == 10) temperature_choix = YSI_10;
                    if (temperature_value == 11) temperature_choix = YSI_11;
                }
                if (update_tension == true)
                {
                    //Tension
                    int tension_value = (int)nud_choix_voie_mesure.Value;
                    if (tension_value == 1) Vchoix = V1;
                    if (tension_value == 2) Vchoix = V2;
                    if (tension_value == 3) Vchoix = V3;
                    if (tension_value == 4) Vchoix = V4;
                    if (tension_value == 5) Vchoix = V5;
                    if (tension_value == 6) Vchoix = V6;
                    if (tension_value == 7) V_choix = V_teensy;
                    if (tension_value == 8) V_choix = vbat_data_logger;
                }
                liste_temperature_double.Add(temperature_ysi);
                liste_choixtemperature.Add(temperature_choix);
                liste_vbat_double.Add(vbat_data_logger);
                liste_5Vteensy.Add(V_teensy);
                liste_choixtension.Add(V_choix);
                //tension.Add()
                //liste_all_temperature_double.Add()

                liste_date_OA.Add(DateTime.Now.ToOADate());
                //liste_date

                liste_all_temperatures_d.Add(all_temperatures_ysi);
                //liste_all_dates_OA.Add(DateTime.Now.ToOADate());


                if (liste_temperature_double.Count > (3600 * 24))
                {
                    liste_temperature_double.RemoveAt(0);
                    liste_date_OA.RemoveAt(0);
                }
                if (liste_choixtemperature.Count > (3600 * 24))
                {
                    liste_choixtemperature.RemoveAt(0);
                    liste_date_OA.RemoveAt(0);
                }


                double[] arrayTempDouble = new double[liste_temperature_double.Count];
                double[] arrayVbatpDouble = new double[liste_vbat_double.Count];
                double[] arrayDateOA = new double[liste_date_OA.Count];
                double[] array5Vteensy = new double[liste_5Vteensy.Count];
                double[] arraychoixtension = new double[liste_choixtension.Count];
                double[] arraychoixtemperature = new double[liste_choixtemperature.Count];
                //double[] arraytension = new double[tension.Count]
                liste_temperature_double.CopyTo(arrayTempDouble);
                liste_vbat_double.CopyTo(arrayVbatpDouble);
                liste_date_OA.CopyTo(arrayDateOA);
                liste_5Vteensy.CopyTo(array5Vteensy);
                liste_choixtension.CopyTo(arraychoixtension);
                liste_choixtemperature.CopyTo(arraychoixtemperature);

                formsPlot_Temperature.plt.Clear();

                formsPlot_Temperature.plt.PlotScatter(arrayDateOA, arrayTempDouble, Color.Blue, markerSize: 2,
                    markerShape: ScottPlot.MarkerShape.openCircle,
                    lineWidth: 0,
                   lineStyle: ScottPlot.LineStyle.Dot);
                formsPlot_Temperature.plt.PlotScatter(arrayDateOA, arraychoixtemperature, Color.Red, markerSize: 2,
                    markerShape: ScottPlot.MarkerShape.openCircle,
                    lineWidth: 0,
                   lineStyle: ScottPlot.LineStyle.Dot);
                formsPlot_Temperature.plt.AxisAuto();
                formsPlot_Temperature.plt.Ticks(dateTimeX: true);
                formsPlot_Temperature.Render();
                formsPlot2.plt.Clear();

                formsPlot2.plt.PlotScatter(arrayDateOA, array5Vteensy, Color.Red, markerSize: 2,
                    markerShape: ScottPlot.MarkerShape.openCircle,
                    lineWidth: 0,
                   lineStyle: ScottPlot.LineStyle.Dot);
                formsPlot2.plt.PlotScatter(arrayDateOA, arrayVbatpDouble, Color.Green, markerSize: 2,
                    markerShape: ScottPlot.MarkerShape.openCircle,
                    lineWidth: 0,
                   lineStyle: ScottPlot.LineStyle.Dot);
                formsPlot2.plt.PlotScatter(arrayDateOA, arraychoixtension, Color.Blue, markerSize: 2,
                    markerShape: ScottPlot.MarkerShape.openCircle,
                    lineWidth: 0,
                   lineStyle: ScottPlot.LineStyle.Dot);
                formsPlot2.plt.AxisAuto();
                formsPlot2.plt.Ticks(dateTimeX: true);
                formsPlot2.Render();
                indice_point++;
                //formsPlot2.plt.PlotScatter(arrayDate0A, )
            }
        }

        public void envoyer_ordre_teensy(string chaine_a_envoyer)
        {
            chaine_a_envoyer += "*";
            char crc_calcule = crc_xor(chaine_a_envoyer);
            chaine_a_envoyer += Convert.ToByte(crc_calcule).ToString("X2");
            char NewLine = (char)0x0A;
            chaine_a_envoyer += NewLine.ToString();
            serialPort1.Write(chaine_a_envoyer);

            textBox_ordre_envoye.Text = chaine_a_envoyer;
        }

        private void button_UPDATE_RTC_Click(object sender, EventArgs e)
        {
            if (port_is_open == true)
            {
                string chaine_update_rtc = "#HEURE;" + DateTime.Now.Hour.ToString() + ";" + DateTime.Now.Minute.ToString() + ";" + DateTime.Now.Second.ToString() + ";";
                envoyer_ordre_teensy(chaine_update_rtc);
            }
        }

        private void button_LED_ROUGE_ON_Click(object sender, EventArgs e)
        {
            if (port_is_open == true)
            {
                string chaine_update_rtc = "#LED;2;1;";
                envoyer_ordre_teensy(chaine_update_rtc);
            }
        }

        private void button_LED_ROUGE_OFF_Click(object sender, EventArgs e)
        {
            if (port_is_open == true)
            {
                string chaine_update_rtc = "#LED;2;0;";
                envoyer_ordre_teensy(chaine_update_rtc);
            }
        }

        private void buttonLED_VERTE_ON_Click(object sender, EventArgs e)
        {
            if (port_is_open == true)
            {
                string chaine_update_rtc = "#LED;0;1;";
                envoyer_ordre_teensy(chaine_update_rtc);
            }
        }

        private void buttonLED_VERTE_OFF_Click(object sender, EventArgs e)
        {
            if (port_is_open == true)
            {
                string chaine_update_rtc = "#LED;0;0;";
                envoyer_ordre_teensy(chaine_update_rtc);
            }
        }
        int last_state_red_led = 0;
        bool autoswitch_red_led = false;
        int etat_pwm_rouge = 0;
        int etat_pwm_vert = 0;
        int etat_pwm_bleu = 0;

        private void nud_temperature_ysi_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e) //Sine
        {
            if (port_is_open == true)
            {
                int frequency = (int)nud_frequency.Value;
                int amplitude = (int)nud_amplitude.Value;
                string chaine_update_logger = "#SINE;" + frequency.ToString() + ";" +amplitude.ToString() + ";";
                envoyer_ordre_teensy(chaine_update_logger);
            }
        }

        private void button10_Click(object sender, EventArgs e) //DC
        {
            if (port_is_open == true)
            {
                int amplitude = (int)nud_amplitude.Value;
                string chaine_update_logger = "#DC;" + amplitude.ToString() + ";";
                envoyer_ordre_teensy(chaine_update_logger);
            }
        }

        private void button_triangular_Click(object sender, EventArgs e)
        {
            if (port_is_open == true)
            {
                int frequency = (int)nud_frequency.Value;
                int amplitude = (int)nud_amplitude.Value;
                string chaine_update_logger = "#TRIANGULAR;" + frequency.ToString() + ";" + amplitude.ToString() + ";";
                envoyer_ordre_teensy(chaine_update_logger);
            }
        }

        private void nud_frequency_ValueChanged(object sender, EventArgs e)
        {

        }

        private void timer_ON_OFF_Tick(object sender, EventArgs e)
        {


            if (port_is_open == true && autoswitch_red_led == true)
            {

                string chaine_rgb = "#RGB" + ";" + (etat_pwm_rouge % 256).ToString() + ";";
                chaine_rgb += (etat_pwm_bleu % 256).ToString() + ";";
                chaine_rgb += (etat_pwm_vert % 256).ToString() + ";";
                envoyer_ordre_teensy(chaine_rgb);
                etat_pwm_bleu += 32;
                if ((etat_pwm_bleu % 256) == 0)
                {
                    etat_pwm_vert += 32;
                    if ((etat_pwm_vert % 256) == 0)
                    {
                        etat_pwm_rouge += 32;
                    }
                }

            }
        }

        private void button_auto_switch_Click(object sender, EventArgs e)
        {
            //if (autoswitch_red_led == false)
            autoswitch_red_led = !autoswitch_red_led;// true;
        }

        private void button_stop_logger_Click(object sender, EventArgs e)
        {
            string chaine_update_logger = "#LOGGER;0;";
            envoyer_ordre_teensy(chaine_update_logger);


        }

        private void button_start_logger_Click(object sender, EventArgs e)
        {
            int periode_logger_ms = (int)nud_periode_logger_secondes.Value;
            periode_logger_ms *= 1000;
            string chaine_update_logger = "#LOGGER;" + periode_logger_ms.ToString() + ";";
            envoyer_ordre_teensy(chaine_update_logger);


        }

        private void button1_Click(object sender, EventArgs e)
        {
            button9.BackColor = Color.Green;
            if (port_is_open == true)
            {
                string chaine_update_rtc = "#RELAIS;1;1;";
                envoyer_ordre_teensy(chaine_update_rtc);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button9.BackColor = Color.Red;
            if (port_is_open == true)
            {
                string chaine_update_rtc = "#RELAIS;1;0;";
                envoyer_ordre_teensy(chaine_update_rtc);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button13.BackColor = Color.Green;
            if (port_is_open == true)
            {
                string chaine_update_rtc = "#GPIO;0;1;";
                envoyer_ordre_teensy(chaine_update_rtc);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button13.BackColor = Color.Red;
            if (port_is_open == true)
            {
                string chaine_update_rtc = "#GPIO;0;0;";
                envoyer_ordre_teensy(chaine_update_rtc);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button7.BackColor = Color.Green;
            if (port_is_open == true)
            {
                string chaine_update_rtc = "#RELAIS;2;1;";
                envoyer_ordre_teensy(chaine_update_rtc);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button7.BackColor = Color.Red; 
            
            if (port_is_open == true)
            {
                string chaine_update_rtc = "#RELAIS;2;0;";
                envoyer_ordre_teensy(chaine_update_rtc);
            }
        }

        private void button_rgb_Click(object sender, EventArgs e)
        {
            if (port_is_open == true)
            {
                int red_rgb = (int)nud_red_rgb.Value;
                int green_rgb = (int)nud_green_rgb.Value;
                int blue_rgb = (int)nud_blue_rgb.Value;
                string chaine_update_rgb = "#RGB;" + red_rgb.ToString() + ";" + green_rgb.ToString() + ";" + blue_rgb.ToString() + ";";
                envoyer_ordre_teensy(chaine_update_rgb);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            update_temperature = true;
        }

        private void button_tension_Click(object sender, EventArgs e) //button update voltage
        {
            update_tension = true;

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
