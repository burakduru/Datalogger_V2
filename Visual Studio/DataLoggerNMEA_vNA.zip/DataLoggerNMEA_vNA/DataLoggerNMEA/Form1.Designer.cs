﻿namespace DataLoggerNMEA
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.formsPlot_Temperature = new ScottPlot.FormsPlot();
            this.OpenCloseSerialPort = new System.Windows.Forms.Button();
            this.formsPlot2 = new ScottPlot.FormsPlot();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.button_refresh_com_port = new System.Windows.Forms.Button();
            this.textBox_Argument = new System.Windows.Forms.TextBox();
            this.button_reset_graph_1 = new System.Windows.Forms.Button();
            this.timer_refresh_graph = new System.Windows.Forms.Timer(this.components);
            this.button_UPDATE_RTC = new System.Windows.Forms.Button();
            this.button_LED_ROUGE_ON = new System.Windows.Forms.Button();
            this.button_LED_ROUGE_OFF = new System.Windows.Forms.Button();
            this.buttonLED_VERTE_ON = new System.Windows.Forms.Button();
            this.buttonLED_VERTE_OFF = new System.Windows.Forms.Button();
            this.timer_ON_OFF = new System.Windows.Forms.Timer(this.components);
            this.button_auto_switch = new System.Windows.Forms.Button();
            this.textBox_ordre_envoye = new System.Windows.Forms.TextBox();
            this.button_stop_logger = new System.Windows.Forms.Button();
            this.button_start_logger = new System.Windows.Forms.Button();
            this.nud_periode_logger_secondes = new System.Windows.Forms.NumericUpDown();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.nud_red_rgb = new System.Windows.Forms.NumericUpDown();
            this.button_rgb = new System.Windows.Forms.Button();
            this.nud_green_rgb = new System.Windows.Forms.NumericUpDown();
            this.nud_blue_rgb = new System.Windows.Forms.NumericUpDown();
            this.nud_choix_voie_mesure = new System.Windows.Forms.NumericUpDown();
            this.button_tension = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.nud_temperature_ysi = new System.Windows.Forms.NumericUpDown();
            this.button7 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button_dc = new System.Windows.Forms.Button();
            this.button_triangular = new System.Windows.Forms.Button();
            this.button_sine = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.nud_frequency = new System.Windows.Forms.NumericUpDown();
            this.nud_amplitude = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.nud_periode_logger_secondes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_red_rgb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_green_rgb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_blue_rgb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_choix_voie_mesure)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_temperature_ysi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_frequency)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_amplitude)).BeginInit();
            this.SuspendLayout();
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // formsPlot_Temperature
            // 
            this.formsPlot_Temperature.Location = new System.Drawing.Point(23, 12);
            this.formsPlot_Temperature.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.formsPlot_Temperature.Name = "formsPlot_Temperature";
            this.formsPlot_Temperature.Size = new System.Drawing.Size(617, 201);
            this.formsPlot_Temperature.TabIndex = 0;
            // 
            // OpenCloseSerialPort
            // 
            this.OpenCloseSerialPort.Location = new System.Drawing.Point(1002, 35);
            this.OpenCloseSerialPort.Name = "OpenCloseSerialPort";
            this.OpenCloseSerialPort.Size = new System.Drawing.Size(64, 94);
            this.OpenCloseSerialPort.TabIndex = 1;
            this.OpenCloseSerialPort.Text = "Open COM";
            this.OpenCloseSerialPort.UseVisualStyleBackColor = true;
            this.OpenCloseSerialPort.Click += new System.EventHandler(this.OpenCloseSerialPort_Click);
            // 
            // formsPlot2
            // 
            this.formsPlot2.Location = new System.Drawing.Point(23, 219);
            this.formsPlot2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.formsPlot2.Name = "formsPlot2";
            this.formsPlot2.Size = new System.Drawing.Size(617, 201);
            this.formsPlot2.TabIndex = 2;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(23, 426);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(1045, 22);
            this.textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(755, 136);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(312, 20);
            this.textBox2.TabIndex = 4;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(829, 35);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(169, 95);
            this.listBox1.TabIndex = 5;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // button_refresh_com_port
            // 
            this.button_refresh_com_port.Location = new System.Drawing.Point(755, 35);
            this.button_refresh_com_port.Name = "button_refresh_com_port";
            this.button_refresh_com_port.Size = new System.Drawing.Size(68, 94);
            this.button_refresh_com_port.TabIndex = 6;
            this.button_refresh_com_port.Text = "Refresh COM Ports Name";
            this.button_refresh_com_port.UseVisualStyleBackColor = true;
            this.button_refresh_com_port.Click += new System.EventHandler(this.button_refresh_com_port_Click);
            // 
            // textBox_Argument
            // 
            this.textBox_Argument.Location = new System.Drawing.Point(755, 193);
            this.textBox_Argument.Multiline = true;
            this.textBox_Argument.Name = "textBox_Argument";
            this.textBox_Argument.ReadOnly = true;
            this.textBox_Argument.Size = new System.Drawing.Size(312, 227);
            this.textBox_Argument.TabIndex = 7;
            // 
            // button_reset_graph_1
            // 
            this.button_reset_graph_1.Location = new System.Drawing.Point(647, 12);
            this.button_reset_graph_1.Name = "button_reset_graph_1";
            this.button_reset_graph_1.Size = new System.Drawing.Size(68, 54);
            this.button_reset_graph_1.TabIndex = 8;
            this.button_reset_graph_1.Text = "Reset Graph";
            this.button_reset_graph_1.UseVisualStyleBackColor = true;
            this.button_reset_graph_1.Click += new System.EventHandler(this.button_reset_graph_1_Click);
            // 
            // timer_refresh_graph
            // 
            this.timer_refresh_graph.Enabled = true;
            this.timer_refresh_graph.Tick += new System.EventHandler(this.timer_refresh_graph_Tick);
            // 
            // button_UPDATE_RTC
            // 
            this.button_UPDATE_RTC.Location = new System.Drawing.Point(646, 359);
            this.button_UPDATE_RTC.Name = "button_UPDATE_RTC";
            this.button_UPDATE_RTC.Size = new System.Drawing.Size(70, 54);
            this.button_UPDATE_RTC.TabIndex = 9;
            this.button_UPDATE_RTC.Text = "Update RTC";
            this.button_UPDATE_RTC.UseVisualStyleBackColor = true;
            this.button_UPDATE_RTC.Click += new System.EventHandler(this.button_UPDATE_RTC_Click);
            // 
            // button_LED_ROUGE_ON
            // 
            this.button_LED_ROUGE_ON.Location = new System.Drawing.Point(23, 484);
            this.button_LED_ROUGE_ON.Name = "button_LED_ROUGE_ON";
            this.button_LED_ROUGE_ON.Size = new System.Drawing.Size(89, 46);
            this.button_LED_ROUGE_ON.TabIndex = 10;
            this.button_LED_ROUGE_ON.Text = "RED LED ON";
            this.button_LED_ROUGE_ON.UseVisualStyleBackColor = true;
            this.button_LED_ROUGE_ON.Click += new System.EventHandler(this.button_LED_ROUGE_ON_Click);
            // 
            // button_LED_ROUGE_OFF
            // 
            this.button_LED_ROUGE_OFF.Location = new System.Drawing.Point(23, 536);
            this.button_LED_ROUGE_OFF.Name = "button_LED_ROUGE_OFF";
            this.button_LED_ROUGE_OFF.Size = new System.Drawing.Size(89, 46);
            this.button_LED_ROUGE_OFF.TabIndex = 11;
            this.button_LED_ROUGE_OFF.Text = "RED LED OFF";
            this.button_LED_ROUGE_OFF.UseVisualStyleBackColor = true;
            this.button_LED_ROUGE_OFF.Click += new System.EventHandler(this.button_LED_ROUGE_OFF_Click);
            // 
            // buttonLED_VERTE_ON
            // 
            this.buttonLED_VERTE_ON.Location = new System.Drawing.Point(231, 484);
            this.buttonLED_VERTE_ON.Name = "buttonLED_VERTE_ON";
            this.buttonLED_VERTE_ON.Size = new System.Drawing.Size(89, 46);
            this.buttonLED_VERTE_ON.TabIndex = 12;
            this.buttonLED_VERTE_ON.Text = "GREEN LED ON";
            this.buttonLED_VERTE_ON.UseVisualStyleBackColor = true;
            this.buttonLED_VERTE_ON.Click += new System.EventHandler(this.buttonLED_VERTE_ON_Click);
            // 
            // buttonLED_VERTE_OFF
            // 
            this.buttonLED_VERTE_OFF.Location = new System.Drawing.Point(231, 536);
            this.buttonLED_VERTE_OFF.Name = "buttonLED_VERTE_OFF";
            this.buttonLED_VERTE_OFF.Size = new System.Drawing.Size(89, 46);
            this.buttonLED_VERTE_OFF.TabIndex = 13;
            this.buttonLED_VERTE_OFF.Text = "GREEN LED OFF";
            this.buttonLED_VERTE_OFF.UseVisualStyleBackColor = true;
            this.buttonLED_VERTE_OFF.Click += new System.EventHandler(this.buttonLED_VERTE_OFF_Click);
            // 
            // timer_ON_OFF
            // 
            this.timer_ON_OFF.Enabled = true;
            this.timer_ON_OFF.Tick += new System.EventHandler(this.timer_ON_OFF_Tick);
            // 
            // button_auto_switch
            // 
            this.button_auto_switch.Location = new System.Drawing.Point(118, 484);
            this.button_auto_switch.Name = "button_auto_switch";
            this.button_auto_switch.Size = new System.Drawing.Size(89, 98);
            this.button_auto_switch.TabIndex = 14;
            this.button_auto_switch.Text = "RGB SWITCH AUTO";
            this.button_auto_switch.UseVisualStyleBackColor = true;
            this.button_auto_switch.Click += new System.EventHandler(this.button_auto_switch_Click);
            // 
            // textBox_ordre_envoye
            // 
            this.textBox_ordre_envoye.Location = new System.Drawing.Point(719, 484);
            this.textBox_ordre_envoye.Multiline = true;
            this.textBox_ordre_envoye.Name = "textBox_ordre_envoye";
            this.textBox_ordre_envoye.ReadOnly = true;
            this.textBox_ordre_envoye.Size = new System.Drawing.Size(348, 46);
            this.textBox_ordre_envoye.TabIndex = 15;
            // 
            // button_stop_logger
            // 
            this.button_stop_logger.Location = new System.Drawing.Point(647, 72);
            this.button_stop_logger.Name = "button_stop_logger";
            this.button_stop_logger.Size = new System.Drawing.Size(68, 54);
            this.button_stop_logger.TabIndex = 16;
            this.button_stop_logger.Text = "Stop Logger";
            this.button_stop_logger.UseVisualStyleBackColor = true;
            this.button_stop_logger.Click += new System.EventHandler(this.button_stop_logger_Click);
            // 
            // button_start_logger
            // 
            this.button_start_logger.Location = new System.Drawing.Point(647, 132);
            this.button_start_logger.Name = "button_start_logger";
            this.button_start_logger.Size = new System.Drawing.Size(68, 54);
            this.button_start_logger.TabIndex = 17;
            this.button_start_logger.Text = "Start Logger";
            this.button_start_logger.UseVisualStyleBackColor = true;
            this.button_start_logger.Click += new System.EventHandler(this.button_start_logger_Click);
            // 
            // nud_periode_logger_secondes
            // 
            this.nud_periode_logger_secondes.Location = new System.Drawing.Point(647, 192);
            this.nud_periode_logger_secondes.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.nud_periode_logger_secondes.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_periode_logger_secondes.Name = "nud_periode_logger_secondes";
            this.nud_periode_logger_secondes.Size = new System.Drawing.Size(67, 20);
            this.nud_periode_logger_secondes.TabIndex = 18;
            this.nud_periode_logger_secondes.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(326, 484);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 46);
            this.button1.TabIndex = 19;
            this.button1.Text = "RELAY 1 ON";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(435, 484);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(89, 46);
            this.button2.TabIndex = 20;
            this.button2.Text = "RELAY 2 ON";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(546, 484);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(89, 46);
            this.button3.TabIndex = 21;
            this.button3.Text = "GPIO 0 ON";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(546, 536);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(89, 46);
            this.button4.TabIndex = 24;
            this.button4.Text = "GPIO 0 OFF";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(435, 536);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(89, 46);
            this.button5.TabIndex = 23;
            this.button5.Text = "RELAY 2 OFF";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(326, 536);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(89, 46);
            this.button6.TabIndex = 22;
            this.button6.Text = "RELAY 1 OFF";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // nud_red_rgb
            // 
            this.nud_red_rgb.Location = new System.Drawing.Point(719, 536);
            this.nud_red_rgb.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_red_rgb.Name = "nud_red_rgb";
            this.nud_red_rgb.Size = new System.Drawing.Size(67, 20);
            this.nud_red_rgb.TabIndex = 25;
            this.nud_red_rgb.Value = new decimal(new int[] {
            128,
            0,
            0,
            0});
            // 
            // button_rgb
            // 
            this.button_rgb.Location = new System.Drawing.Point(963, 536);
            this.button_rgb.Name = "button_rgb";
            this.button_rgb.Size = new System.Drawing.Size(93, 31);
            this.button_rgb.TabIndex = 28;
            this.button_rgb.Text = "Update RGB";
            this.button_rgb.UseVisualStyleBackColor = true;
            this.button_rgb.Click += new System.EventHandler(this.button_rgb_Click);
            // 
            // nud_green_rgb
            // 
            this.nud_green_rgb.Location = new System.Drawing.Point(792, 536);
            this.nud_green_rgb.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_green_rgb.Name = "nud_green_rgb";
            this.nud_green_rgb.Size = new System.Drawing.Size(67, 20);
            this.nud_green_rgb.TabIndex = 29;
            this.nud_green_rgb.Value = new decimal(new int[] {
            128,
            0,
            0,
            0});
            // 
            // nud_blue_rgb
            // 
            this.nud_blue_rgb.Location = new System.Drawing.Point(865, 536);
            this.nud_blue_rgb.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud_blue_rgb.Name = "nud_blue_rgb";
            this.nud_blue_rgb.Size = new System.Drawing.Size(67, 20);
            this.nud_blue_rgb.TabIndex = 30;
            this.nud_blue_rgb.Value = new decimal(new int[] {
            128,
            0,
            0,
            0});
            // 
            // nud_choix_voie_mesure
            // 
            this.nud_choix_voie_mesure.Location = new System.Drawing.Point(648, 333);
            this.nud_choix_voie_mesure.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.nud_choix_voie_mesure.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nud_choix_voie_mesure.Name = "nud_choix_voie_mesure";
            this.nud_choix_voie_mesure.Size = new System.Drawing.Size(67, 20);
            this.nud_choix_voie_mesure.TabIndex = 31;
            this.nud_choix_voie_mesure.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // button_tension
            // 
            this.button_tension.Location = new System.Drawing.Point(646, 304);
            this.button_tension.Name = "button_tension";
            this.button_tension.Size = new System.Drawing.Size(70, 23);
            this.button_tension.TabIndex = 32;
            this.button_tension.Text = "Voltage";
            this.button_tension.UseVisualStyleBackColor = true;
            this.button_tension.Click += new System.EventHandler(this.button_tension_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(646, 249);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(70, 23);
            this.button8.TabIndex = 33;
            this.button8.Text = "°C";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // nud_temperature_ysi
            // 
            this.nud_temperature_ysi.Location = new System.Drawing.Point(648, 278);
            this.nud_temperature_ysi.Maximum = new decimal(new int[] {
            11,
            0,
            0,
            0});
            this.nud_temperature_ysi.Name = "nud_temperature_ysi";
            this.nud_temperature_ysi.Size = new System.Drawing.Size(66, 20);
            this.nud_temperature_ysi.TabIndex = 34;
            this.nud_temperature_ysi.ValueChanged += new System.EventHandler(this.nud_temperature_ysi_ValueChanged);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Red;
            this.button7.Location = new System.Drawing.Point(461, 455);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(40, 23);
            this.button7.TabIndex = 35;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Red;
            this.button9.Location = new System.Drawing.Point(345, 455);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(40, 23);
            this.button9.TabIndex = 36;
            this.button9.UseVisualStyleBackColor = false;
            // 
            // button_dc
            // 
            this.button_dc.Location = new System.Drawing.Point(874, 162);
            this.button_dc.Name = "button_dc";
            this.button_dc.Size = new System.Drawing.Size(82, 22);
            this.button_dc.TabIndex = 37;
            this.button_dc.Text = "DC ";
            this.button_dc.UseVisualStyleBackColor = true;
            this.button_dc.Click += new System.EventHandler(this.button10_Click);
            // 
            // button_triangular
            // 
            this.button_triangular.Location = new System.Drawing.Point(755, 162);
            this.button_triangular.Name = "button_triangular";
            this.button_triangular.Size = new System.Drawing.Size(82, 22);
            this.button_triangular.TabIndex = 38;
            this.button_triangular.Text = "Triangular";
            this.button_triangular.UseVisualStyleBackColor = true;
            this.button_triangular.Click += new System.EventHandler(this.button_triangular_Click);
            // 
            // button_sine
            // 
            this.button_sine.Location = new System.Drawing.Point(985, 162);
            this.button_sine.Name = "button_sine";
            this.button_sine.Size = new System.Drawing.Size(81, 22);
            this.button_sine.TabIndex = 39;
            this.button_sine.Text = "Sine";
            this.button_sine.UseVisualStyleBackColor = true;
            this.button_sine.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.Red;
            this.button13.Location = new System.Drawing.Point(572, 455);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(40, 23);
            this.button13.TabIndex = 40;
            this.button13.UseVisualStyleBackColor = false;
            // 
            // nud_frequency
            // 
            this.nud_frequency.Location = new System.Drawing.Point(756, 12);
            this.nud_frequency.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nud_frequency.Name = "nud_frequency";
            this.nud_frequency.Size = new System.Drawing.Size(67, 20);
            this.nud_frequency.TabIndex = 41;
            this.nud_frequency.ValueChanged += new System.EventHandler(this.nud_frequency_ValueChanged);
            // 
            // nud_amplitude
            // 
            this.nud_amplitude.Location = new System.Drawing.Point(829, 12);
            this.nud_amplitude.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nud_amplitude.Name = "nud_amplitude";
            this.nud_amplitude.Size = new System.Drawing.Size(65, 20);
            this.nud_amplitude.TabIndex = 42;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1080, 583);
            this.Controls.Add(this.nud_amplitude);
            this.Controls.Add(this.nud_frequency);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button_sine);
            this.Controls.Add(this.button_triangular);
            this.Controls.Add(this.button_dc);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.nud_temperature_ysi);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button_tension);
            this.Controls.Add(this.nud_choix_voie_mesure);
            this.Controls.Add(this.nud_blue_rgb);
            this.Controls.Add(this.nud_green_rgb);
            this.Controls.Add(this.button_rgb);
            this.Controls.Add(this.nud_red_rgb);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.nud_periode_logger_secondes);
            this.Controls.Add(this.button_start_logger);
            this.Controls.Add(this.button_stop_logger);
            this.Controls.Add(this.textBox_ordre_envoye);
            this.Controls.Add(this.button_auto_switch);
            this.Controls.Add(this.buttonLED_VERTE_OFF);
            this.Controls.Add(this.buttonLED_VERTE_ON);
            this.Controls.Add(this.button_LED_ROUGE_OFF);
            this.Controls.Add(this.button_LED_ROUGE_ON);
            this.Controls.Add(this.button_UPDATE_RTC);
            this.Controls.Add(this.button_reset_graph_1);
            this.Controls.Add(this.textBox_Argument);
            this.Controls.Add(this.button_refresh_com_port);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.formsPlot2);
            this.Controls.Add(this.OpenCloseSerialPort);
            this.Controls.Add(this.formsPlot_Temperature);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nud_periode_logger_secondes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_red_rgb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_green_rgb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_blue_rgb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_choix_voie_mesure)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_temperature_ysi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_frequency)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_amplitude)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.IO.Ports.SerialPort serialPort1;
        private ScottPlot.FormsPlot formsPlot_Temperature;
        private System.Windows.Forms.Button OpenCloseSerialPort;
        private ScottPlot.FormsPlot formsPlot2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button_refresh_com_port;
        private System.Windows.Forms.TextBox textBox_Argument;
        private System.Windows.Forms.Button button_reset_graph_1;
        private System.Windows.Forms.Timer timer_refresh_graph;
        private System.Windows.Forms.Button button_UPDATE_RTC;
        private System.Windows.Forms.Button button_LED_ROUGE_ON;
        private System.Windows.Forms.Button button_LED_ROUGE_OFF;
        private System.Windows.Forms.Button buttonLED_VERTE_ON;
        private System.Windows.Forms.Button buttonLED_VERTE_OFF;
        private System.Windows.Forms.Timer timer_ON_OFF;
        private System.Windows.Forms.Button button_auto_switch;
        private System.Windows.Forms.TextBox textBox_ordre_envoye;
        private System.Windows.Forms.Button button_stop_logger;
        private System.Windows.Forms.Button button_start_logger;
        private System.Windows.Forms.NumericUpDown nud_periode_logger_secondes;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.NumericUpDown nud_red_rgb;
        private System.Windows.Forms.Button button_rgb;
        private System.Windows.Forms.NumericUpDown nud_green_rgb;
        private System.Windows.Forms.NumericUpDown nud_blue_rgb;
        private System.Windows.Forms.NumericUpDown nud_choix_voie_mesure;
        private System.Windows.Forms.Button button_tension;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.NumericUpDown nud_temperature_ysi;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button_dc;
        private System.Windows.Forms.Button button_triangular;
        private System.Windows.Forms.Button button_sine;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.NumericUpDown nud_frequency;
        private System.Windows.Forms.NumericUpDown nud_amplitude;
    }
}

